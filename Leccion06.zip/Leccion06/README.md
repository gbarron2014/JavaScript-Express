# Lectura de QR
