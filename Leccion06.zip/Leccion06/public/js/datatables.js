$(document).ready(function() {
    $('#tablaAlumno').DataTable({
        "language":{
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
        }
    });
});

$(document).ready(function() {
    $('#tabla').DataTable({
        "language":{
            "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
        }
    });
});
