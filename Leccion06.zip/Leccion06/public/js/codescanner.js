function showData() {
    document.getElementById('reader').style.display = 'none';
    document.getElementById('result').innerHTML = '<span class="result">' + qrCodeMessage + '</span>';
    fetch('http://localhost:3000/code', {
            headers: {
                'Content-type': 'application/json'
            },
            method: 'POST',
            body: JSON.stringify({ code: qrCodeMessage })
        })
        .then(function(response) {
            // Transforma la respuesta a JSON
            return response.json();
        })
        .then(function(json) {
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: json.estudiante,
                showConfirmButton: false,
                timer: 1000
            });
            //document.getElementById('result').innerHTML = '<span class="row">Nuevo Código</span>';
            console.log("REcibidos " + JSON.stringify(json))
            document.getElementById('reader').style.display = 'block';

        });
}